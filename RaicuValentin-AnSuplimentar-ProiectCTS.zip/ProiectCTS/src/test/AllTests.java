package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestAdaugaEliminaAngajat.class,
		TestCreareAngajat.class, TestFisiere.class,
		TestModificaAngajat.class, TestSingletons.class,TestAcordareMarire.class })

public class AllTests {

}
