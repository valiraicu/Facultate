package test;

import java.io.File;
import java.util.ArrayList;

import junit.framework.TestCase;

import model.Angajat;

import org.junit.Test;

import controllers.Firma;

public class TestFisiere extends TestCase{
	@Test
	public void testCreareFisier() {

		String fileName = "angajati.dat";

		ArrayList<Angajat> angajati = new ArrayList<>();
		Angajat a1 = new Angajat("vasule", "asg", "12515125");
		Angajat a2 = new Angajat("vadshsule", "asdshsdhhafg", "12515125");
		Angajat a3 = new Angajat("vasuasgasale", "awesyewsafg", "12515125");
		angajati.add(a1);
		angajati.add(a2);
		angajati.add(a3);
		for (Angajat a : angajati) {
			Firma.getInstance().adaugaAngajat(a);
		}
		Firma.getInstance().salvareFisier(fileName);

		File file = new File(fileName);

		assertTrue(file.exists());
		file.delete();
	}

	

	@Test
	public void testSalvareCorectaFisier() {

		String fileName = "angajati.dat";

		ArrayList<Angajat> angajati = new ArrayList<>();
		Angajat a1 = new Angajat("vasule", "asg", "12515125");
		Angajat a2 = new Angajat("vadshsule", "asdshsdhhafg", "12515125");
		Angajat a3 = new Angajat("vasuasgasale", "awesyewsafg", "12515125");
		angajati.add(a1);
		angajati.add(a2);
		angajati.add(a3);
		for (Angajat a : angajati) {
			Firma.getInstance().adaugaAngajat(a);
		}
		Firma.getInstance().salvareFisier(fileName);
		Firma.getInstance().getListaAngajati().clear();
		File file = new File(fileName);

		if (file.exists()) {
			Firma.getInstance().citireFisier(fileName);
			if (Firma.getInstance().getListaAngajati().containsAll(angajati)) {
				assertTrue(true);
			} else {
				assertFalse(true);
			}
		}

		file.delete();
	}
	
	@Test
	public void testCitireFisier() {

		String fileName = "angajati.dat";

		ArrayList<Angajat> angajati = new ArrayList<>();
		Angajat a1 = new Angajat("vasule", "asg", "12515125");
		Angajat a2 = new Angajat("vadshsule", "asdshsdhhafg", "12515125");
		Angajat a3 = new Angajat("vasuasgasale", "awesyewsafg", "12515125");
		angajati.add(a1);
		angajati.add(a2);
		angajati.add(a3);

		Firma.getInstance().setListaAngajati(angajati);

		Firma.getInstance().salvareFisier(fileName);
		Firma.getInstance().getListaAngajati().clear();

		File file = new File(fileName);
		Firma.getInstance().citireFisier(fileName);
		System.out.println(Firma.getInstance().getListaAngajati().size());
		if (Firma.getInstance().getListaAngajati().containsAll(angajati)) {
			assertTrue(true);
		} else {
			assertFalse(true);
		}

		file.delete();
	}
	
}


