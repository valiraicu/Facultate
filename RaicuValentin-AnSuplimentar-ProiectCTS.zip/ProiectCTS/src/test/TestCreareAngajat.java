package test;

import static org.junit.Assert.*;

import java.text.ParseException;

import javax.naming.directory.InvalidAttributesException;

import junit.framework.TestCase;

import model.Angajat;

import org.junit.Test;

import builder.EmployeeBuilder;

import exceptions.NullAttributeException;

public class TestCreareAngajat extends TestCase {

	// TESTE CREARE ANGAJAT
	@Test
	public void testCreareAngajatNullValues() {
		Angajat a;
		try {
			a = new Angajat(null, null, null, null);
			assertTrue(false);
		} catch (InvalidAttributesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullAttributeException e) {
			assertTrue(true);
			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}

	}

	@Test
	public void testCreareAngajatEmptyFields() {
		Angajat a;
		try {
			a = new Angajat("", "", "", "");
			assertTrue(false);
		} catch (InvalidAttributesException e) {
			assertTrue(true);
			e.printStackTrace();
		} catch (NullAttributeException e) {
			// assertTrue(true);
			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}

	}

	@Test
	public void testCreareAngajatBadDateFormat() {
		Angajat a;
		try {
			a = new Angajat("Giani", "Gigel", "12414", "12566a236");
			assertTrue(false);
		} catch (InvalidAttributesException e) {

			e.printStackTrace();
		} catch (NullAttributeException e) {
			// assertTrue(true);
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	// BUILDER
	@Test
	public void testBuildAngajat() {
		String date = "25/04/2015";
		EmployeeBuilder builder = new EmployeeBuilder();
		builder.nume_set("Vasile").setPrenume("Ion").setCnp("1251521");
		builder.setDataAngajare(date);
		Angajat a = builder.build();

		assertNotNull(a);
	}
	
	@Test
	public void testEmailValid(){
		Angajat a = new Angajat();
		try {
			a.setEmail("giani@ase.ro");
			assertTrue(true);
		} catch (InvalidAttributesException e) {
			assertTrue(false);
			e.printStackTrace();
		}
	}
	
	public void testEmailInvalid(){
		Angajat a = new Angajat();
		try {
			a.setEmail("gasgagasg");
			assertTrue(false);
		} catch (InvalidAttributesException e) {
			assertTrue(true);
			e.printStackTrace();
		}
	}

}
