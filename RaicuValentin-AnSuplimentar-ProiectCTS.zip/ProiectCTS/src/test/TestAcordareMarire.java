package test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.util.ArrayList;

import javax.naming.directory.InvalidAttributesException;

import junit.framework.TestCase;

import model.Angajat;

import org.junit.Test;

import controllers.Firma;

import exceptions.NullAttributeException;

public class TestAcordareMarire extends TestCase {

	// TESTE ACORDARE MARIRE
	@Test
	public void testAcordareMarireCorect() {
		Angajat a = null;
		try {
			a = new Angajat("fsg", "qweaghh", "234512512", "21/05/2006");
		} catch (InvalidAttributesException e) {

			e.printStackTrace();
		} catch (NullAttributeException e) {

			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}
		a.setSalariu(2500);
		a.acordaMarireSalariu();
		assertTrue(2500 < a.getSalariu());

	}

	@Test
	public void testAcordareMarireVechimeMaiMica() {
		Angajat a = null;
		try {
			a = new Angajat("asg", "asgaghh", "33512512", "11/05/2014");
		} catch (InvalidAttributesException e) {

			e.printStackTrace();
		} catch (NullAttributeException e) {

			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}
		a.setSalariu(2500);
		a.acordaMarireSalariu();
		assertEquals(2500.0, a.getSalariu());

	}
	
	@Test
	public void testGetAngajatiVechime() {
		
		ArrayList<Angajat> angajati = new ArrayList<>();
	
		try {
			Angajat a1 = new Angajat("anga1", "asd", "234234","11/01/2000");
			Angajat a3 = new Angajat("aga2", "asd", "435345","11/01/2011");
			Angajat a2 = new Angajat("asd3", "qwe", "1233125","11/01/2014");
			Angajat a4 = new Angajat("asda3", "qwe", "5435125","11/01/1995");
		
			angajati.add(a1);
			angajati.add(a2);
			angajati.add(a3);
			angajati.add(a4);
		
		} catch (InvalidAttributesException e) {
			
			e.printStackTrace();
		} catch (NullAttributeException e) {
			
			e.printStackTrace();
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		
		for (Angajat a : angajati) {
			Firma.getInstance().adaugaAngajat(a);
		}
		
		ArrayList<Angajat> angajatiVechime = Firma.getInstance().getAngajatiCuVechime();
		assertEquals(4, angajatiVechime.size());
		
		

	}
	

}
