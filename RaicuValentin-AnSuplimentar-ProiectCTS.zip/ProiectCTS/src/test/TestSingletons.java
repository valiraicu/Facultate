package test;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import vizual.MainFrame;

import controllers.Firma;

public class TestSingletons extends TestCase {

	// TESTE SINGLETON


		@Test
		public void testMainFrameSingletonNotNull() {
			MainFrame mf1 = MainFrame.getInstance();
			assertNotNull(mf1);
		}
		
		@Test
		public void testSingletonNotNull() {
			Firma firma1 = Firma.getInstance();
			assertNotNull(firma1);
		}


		@Test
		public void testSingletonSame() {
			Firma firma1 = Firma.getInstance();
			assertSame(Firma.getInstance(), firma1);
		}

	
		@Test
		public void testMainFrameSingletonSame() {
			MainFrame mf1 = MainFrame.getInstance();
			MainFrame mf2 = MainFrame.getInstance();
			assertSame(mf1, mf2);
		}
		
}
