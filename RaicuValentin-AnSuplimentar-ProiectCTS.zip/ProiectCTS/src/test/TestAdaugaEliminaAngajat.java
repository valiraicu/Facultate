package test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import junit.framework.TestCase;

import model.Angajat;

import org.junit.Test;

import controllers.Firma;
import exceptions.AngajatInexistentException;

public class TestAdaugaEliminaAngajat extends TestCase{

	// Firma firma;
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	// assigning the values
	protected void setUp() {
		// firma = Firma.getInstance();
	}

	protected void tearDown() {
		Firma.getInstance().getListaAngajati().clear();
	}

	@Test
	public void testEliminaAngajatException() {
		try {
			Angajat a = new Angajat("Popescu", "John", "12515");
			Firma.getInstance().eliminaAngajat(a);
			assertFalse("NU a fost aruncata exceptia", true);
		} catch (AngajatInexistentException e) {
			assertTrue("Exceptia asteptata a fost aruncata", true);
			e.printStackTrace();
		}
	}
	
	
	// TEST ADAUGARE ANGAJAT
	@Test
	public void testAdaugaAngajat() {
		Angajat a = new Angajat("vasule", "asafg", "12515125");
		Firma.getInstance().adaugaAngajat(a);
		assertEquals(Firma.getInstance().getListaAngajati().size(), 1);
	}

	// Elimina ANgajat
	@Test
	public void testEliminaAngajat() throws AngajatInexistentException {

		ArrayList<Angajat> angajati = new ArrayList<>();
		Angajat a1 = new Angajat("vasule", "asafg", "12515125");
		Angajat a2 = new Angajat("vasule", "asafg", "12515125");
		Angajat a3 = new Angajat("vasule", "asafg", "12515125");
		angajati.add(a1);
		angajati.add(a2);
		angajati.add(a3);
		for (Angajat a : angajati) {
			Firma.getInstance().adaugaAngajat(a);
		}
		Firma.getInstance().eliminaAngajat(a2);
		assertTrue(Firma.getInstance().getListaAngajati().size() < angajati
				.size());
	}
	


	

}
