package test;

import static org.junit.Assert.*;

import java.text.ParseException;

import javax.naming.directory.InvalidAttributesException;

import junit.framework.TestCase;

import model.Angajat;

import org.junit.Test;

import controllers.Firma;
import exceptions.AngajatInexistentException;
import exceptions.NullAttributeException;

public class TestModificaAngajat extends TestCase{
	
	protected void tearDown() {
		Firma.getInstance().getListaAngajati().clear();
	}

	// TESTE MODIFICA ANGAJAT
	@Test
	public void testModificaDataAngajariiInexistentException() {
		try {
			String s = "23/01/1999";

			Firma.getInstance().modificaEmployeeDate(new Angajat(), s);
			assertFalse("NU a fost aruncata exceptia", true);
		} catch (AngajatInexistentException e) {
			assertTrue("Exceptia asteptata a fost aruncata", true);
			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testModificaDateAngajatInvalidAtrributesException() {
		try {
			Angajat a = new Angajat("Stefan", "Micutul", "345345");
			Firma.getInstance().adaugaAngajat(a);
			try {
				Firma.getInstance().changeDate(a, "", "");
				assertFalse("NU a fost aruncata exceptia", true);
			} catch (InvalidAttributesException e) {
				assertTrue("Exceptia asteptata a fost aruncata", true);
				e.printStackTrace();
			} catch (NullAttributeException e) {

				e.printStackTrace();
			}

		} catch (AngajatInexistentException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testModificaDateAngajatInexistentException() {
		try {
			Angajat a = new Angajat("Jiji", "iop", "43245");
			Firma.getInstance().changeDate(a, "Giani", "Semafor");
			assertFalse("NU a fost aruncata exceptia", true);
		} catch (AngajatInexistentException e) {
			assertTrue("Exceptia asteptata a fost aruncata", true);
			e.printStackTrace();
		} catch (InvalidAttributesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullAttributeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testModificaDateAngajatNullAttributeException() {
		try {
			Angajat a = new Angajat(null, null, null);
			Firma.getInstance().adaugaAngajat(a);
			try {
				Firma.getInstance().changeDate(a, "Nea Caisa", "Zidaru");
				assertFalse("NU a fost aruncata exceptia", true);
			} catch (InvalidAttributesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NullAttributeException e) {
				assertTrue("Exceptia asteptata a fost aruncata", true);
				e.printStackTrace();
			}

		} catch (AngajatInexistentException e) {

			e.printStackTrace();
		}
	}
	
	@Test
	public void testModificaDataAngajariiFormatException() {
		try {
			String s = "21-05.1993";
			Angajat a = new Angajat("Aspirator", "Magdalena", "555666");
			Firma.getInstance().adaugaAngajat(a);
			Firma.getInstance().modificaEmployeeDate(a, s);
			assertFalse("NU a fost aruncata exceptia", true);
		} catch (AngajatInexistentException e) {

			e.printStackTrace();
		} catch (ParseException e) {
			assertTrue("Exceptia asteptata a fost aruncata", true);
			e.printStackTrace();
		}
	}

	

}
