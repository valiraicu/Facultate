package model;

import java.util.*;
import java.io.*;
import java.io.ObjectInputStream.GetField;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.naming.directory.InvalidAttributesException;

import exceptions.NullAttributeException;

public class Angajat implements Serializable {

	
	private String prenume;
	private String nume;
	private Date dataAngajare;
	private String cnp;

	private double salariu;

	private String email;

	public String getNume() {
		return this.nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public String getPrenume() {
		return this.prenume;
	}

	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}

	public String getCnp() {
		return this.cnp;
	}

	public void setCnp(String cnp) {
		this.cnp = cnp;
	}

	public Date getDataAngajare() {
		return this.dataAngajare;
	}

	public void setDataAngajare(Date d) {
		this.dataAngajare = d;
	}

	public double getSalariu() {
		return salariu;
	}

	public void setSalariu(double d) {
		this.salariu = d;
	}

	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String d = "Invalid date";
		try {
			d = sdf.format(this.dataAngajare);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.nume + " " + this.prenume + " " + this.cnp + " " + d;

	}

	public Angajat() {
		super();
	}

	public Angajat(String nume, String prenume, String cnp, String dataAngajare)
			throws InvalidAttributesException, NullAttributeException,
			ParseException {
		if (nume != null) {
			if (!nume.equals("")) {
				this.nume = nume;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		if (prenume != null) {
			if (!prenume.equals("")) {
				this.prenume = prenume;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		if (cnp != null) {
			if (!cnp.equals("")) {
				this.cnp = cnp;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Date date = sdf.parse(dataAngajare);

		this.cnp = cnp;
		this.dataAngajare = date;
	}

	public Angajat(String nume, String prenume, String cnp) {
		this.nume = nume;
		this.prenume = prenume;
		this.cnp = cnp;

	}

	public String getEmail() {
		return email;
	}
	
	public Angajat(String nume, String prenume, String cnp,
			String dataAngajare, double salariu)
			throws InvalidAttributesException, NullAttributeException,
			ParseException {
		if (nume != null) {
			if (!nume.equals("")) {
				this.nume = nume;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		if (prenume != null) {
			if (!prenume.equals("")) {
				this.prenume = prenume;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		if (cnp != null) {
			if (!cnp.equals("")) {
				this.cnp = cnp;
			} else {
				throw new InvalidAttributesException();
			}
		} else {
			throw new NullAttributeException();
		}

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Date date = sdf.parse(dataAngajare);

		this.cnp = cnp;
		this.dataAngajare = date;
	}
	
	public int calculeazaVechime() {
		Calendar calendar1 = Calendar.getInstance(Locale.ENGLISH);
		calendar1.setTime(this.getDataAngajare());

		Calendar calendarNow = Calendar.getInstance(Locale.ENGLISH);
		calendarNow.setTime(new Date());

		int vechime = calendarNow.get(Calendar.YEAR)
				- calendar1.get(Calendar.YEAR);
		if (calendar1.get(Calendar.MONTH) > calendarNow.get(Calendar.MONTH)
				|| (calendar1.get(Calendar.MONTH) == calendarNow
						.get(Calendar.MONTH) && calendar1.get(Calendar.DATE) > calendarNow
						.get(Calendar.DATE))) {
			vechime--;
		}
		return vechime;
	}

	
	public boolean equals(Object o) {
		if (o == null)
			return false;
		else if (o instanceof Angajat) {
			Angajat a = (Angajat) o;
			if (this.cnp != null && a.cnp != null) {
				return this.cnp.equals(a.cnp);
			}
		} else {
			return false;
		}
		return false;

	}

	public void setEmail(String email) throws InvalidAttributesException {
		String username = "",rest= "",domain="",com="";
		try{
			String[] emailToken = email.split("@");
			username = emailToken[0];
			rest = emailToken[1];
		    String[] parts = rest.split("\\.");
		    domain = parts[0];
		    com = parts[1];
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
			throw new InvalidAttributesException();
		}
		if(username.length() >0 && domain.length()>0 && com.length()>0){
			this.email = email;
		}else{
			throw new InvalidAttributesException();
		}
		
	}

	

	

	
	public void acordaMarireSalariu() {
		if (calculeazaVechime() > 5) {
			setSalariu(this.getSalariu() * 1.2);
		}
	}

}