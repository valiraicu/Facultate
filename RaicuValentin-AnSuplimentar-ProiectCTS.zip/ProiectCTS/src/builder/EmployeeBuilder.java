package builder;

import java.text.ParseException;
import java.util.Date;

import javax.naming.directory.InvalidAttributesException;

import exceptions.NullAttributeException;

import model.Angajat;

public class EmployeeBuilder {

	private String nume;
	private String prenume;
	private String CodNumericPersonal;
	private String dataAngajare;
	
	public Angajat build(){
		try {
			return new Angajat(nume, prenume, CodNumericPersonal, dataAngajare);
		} catch (InvalidAttributesException e) {
			
			e.printStackTrace();
		} catch (NullAttributeException e) {
						e.printStackTrace();
		} catch (ParseException e) {
					e.printStackTrace();
		}
		return null;
	}

	public String nume_get() {
		return nume;
	}

	public EmployeeBuilder nume_set(String nume) {
		this.nume = nume;
		return this;
	}

	public EmployeeBuilder setPrenume(String prenume) {
		this.prenume = prenume;
		return this;
	}
	
	

	public String getPrenume() {
		return prenume;
	}

	
	public String getCnp() {
		return CodNumericPersonal;
	}
	

	
	public EmployeeBuilder setCnp(String cnp) {
		this.CodNumericPersonal = cnp;
		return this;
	}

	public String getDataAngajare() {
		return dataAngajare;
	}

	public EmployeeBuilder setDataAngajare(String dataAngajare) {
		this.dataAngajare = dataAngajare;
		return this;
	}
	
	

}
