package exceptions;

public class NullAttributeException extends Exception{
	public NullAttributeException(){
        super("Numele si prenumele nu pot fi nule");
    }
}
