package obspattern;
public interface EmployeeListener{
    public void listaAngajatiModificata();
}