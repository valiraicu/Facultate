package obspattern;

public interface EmployeeSubject{
    public void addEmployee(EmployeeListener al);
    public void notifyEmployeeListeners();
}