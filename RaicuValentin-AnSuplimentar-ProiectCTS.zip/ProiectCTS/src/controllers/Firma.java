package controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.event.ActionEvent;
import java.io.*;

import javax.naming.directory.InvalidAttributesException;
import javax.swing.JFileChooser;

import exceptions.AngajatInexistentException;
import exceptions.NullAttributeException;

import obspattern.EmployeeListener;
import obspattern.EmployeeSubject;

import model.Angajat;

public class Firma implements EmployeeSubject, Serializable {
	private ArrayList<Angajat> listaAngajati = new ArrayList<Angajat>();
	private static Firma singleton;
	private ArrayList<EmployeeListener> listeners = new ArrayList<>();
	
	public void notifyEmployeeListeners() {
		for (EmployeeListener al : listeners) {
			al.listaAngajatiModificata();
		}
	}
	
	
	
	public ArrayList<Angajat> getAngajatiCuVechime(){
		ArrayList<Angajat> angajati = new ArrayList<>();
		for(Angajat ang:listaAngajati){
			if ( ang.calculeazaVechime() > 5){
				angajati.add(ang);
			} 
		}
		return angajati;
	}

	

	public void setListaAngajati(ArrayList<Angajat> lista) {
		this.listaAngajati = lista;
	}

	public void adaugaAngajat(Angajat a) {
		listaAngajati.add(a);
		// notifyAngajatListeners();
	}
	
	
	public ArrayList<Angajat> getListaAngajati() {
		return this.listaAngajati;
	}

	

	public void eliminaAngajat(Angajat a) throws AngajatInexistentException {
		boolean eliminat = false;
		for (Angajat ang : listaAngajati) {
			if (ang.equals(a)) {
				listaAngajati.remove(a);
				eliminat = true;
				break;
			}
		}
		if (!eliminat) {
			throw new AngajatInexistentException();
		}

		listaAngajati.remove(a);
		notifyEmployeeListeners();
	}

	

	public void addEmployee(EmployeeListener al) {
		listeners.add(al);
	}

	

	public static Firma getInstance() {
		if (singleton == null) {
			singleton = new Firma();
		}
		return singleton;
	}

	private Firma() {

	}
	
	public void changeDate(Angajat a, String nume, String prenume)
			throws AngajatInexistentException, NullAttributeException, InvalidAttributesException {
		if (nume != null && prenume != null) {
			if(!nume.equals("") || !prenume.equals("") ){
				boolean modificat = false;
				for (Angajat a1 : listaAngajati) {
					if (a1.equals(a)) {
						a.setNume(nume);
						a.setPrenume(prenume);
						modificat = true;
						notifyEmployeeListeners();
					}
				}
				if (modificat == false) {
					throw new AngajatInexistentException();
				}
			}else{
				throw new InvalidAttributesException();
			}
			
		}else{
			throw new NullAttributeException();
		}

	}
	
	
	
	public void modificaEmployeeDate(Angajat a, String dateString)
			throws AngajatInexistentException, ParseException {
		

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		Date date = sdf.parse(dateString);
		
		boolean modificat = false;
		for (Angajat a1 : listaAngajati) {
			if (a1.equals(a)) {
				a.setDataAngajare(date);
				notifyEmployeeListeners();
				modificat = true;
				break;
			}
		}
		if (modificat == false) {
			throw new AngajatInexistentException();
		}
	}

	public void salvareFisier(String fileName) {

		ObjectOutputStream out;
		try {
			out = new ObjectOutputStream(new FileOutputStream(
					new File(fileName)));
			out.writeObject(Firma.getInstance().getListaAngajati());
			out.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	
	
	public void citireFisier(String fileName) {

		File file = new File(fileName);
		FileInputStream sursa = null;
		try {
			sursa = new FileInputStream(file);
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		}

		Object o = null;

		ObjectInputStream in;
		try {

			in = new ObjectInputStream(sursa);

			ArrayList<Angajat> lst = null;
			try {
				lst = (ArrayList<Angajat>) in.readObject();

				Firma.getInstance().setListaAngajati(lst);
				Firma.getInstance().notifyEmployeeListeners();
				in.close();
			} catch (Exception ex) {
				in.close();
			}
			;

		} catch (IOException e) {
		
			e.printStackTrace();
		}

	}
	
	
	
}