package vizual;

import java.util.*;

import javax.naming.directory.InvalidAttributesException;
import javax.swing.*;

import controllers.Firma;
import exceptions.AngajatInexistentException;
import exceptions.NullAttributeException;

import model.Angajat;

import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class ModificaDateFrame extends JFrame{
    
  private JButton b1 = new JButton("OK");
    
    private JTextField t1 = new JTextField(12);
    private JLabel e1 = new JLabel("Nume:");
    
    private JTextField t2 = new JTextField(12);
    private JLabel e2 = new JLabel("Prenume:");
    
    private JTextField t3 = new JTextField(12);
    private JLabel e3 = new JLabel("Data Angajarii:");
    
    
    
   
    
    private JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel p3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel p4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel p5 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    
    
    private Angajat ang;
    private Date data;
    
    
    public ModificaDateFrame(Angajat a){
        setLayout(new GridLayout(5,1));
        add(p1);add(p2);add(p3);add(p4);add(p5);
        p1.add(e1);p1.add(t1);
        p2.add(e2);p2.add(t2);
        p3.add(e3);p3.add(t3);
        p5.add(b1);
        
        
        ang = a;
        
        
        t1.setText(ang.getNume());
        t2.setText(ang.getPrenume());
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String d = sdf.format(ang.getDataAngajare());
        t3.setText(d+"");
        b1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
            String nume  = t1.getText();
            String prenume = t2.getText();
            String d1 = t3.getText();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            try{
                 data = sdf.parse(d1);
            }catch(ParseException ex){};
            
            
            
          
            try{
                Firma.getInstance().changeDate(ang,nume,prenume);
                Firma.getInstance().modificaEmployeeDate(ang,d1);
            }catch(AngajatInexistentException e){} catch (InvalidAttributesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NullAttributeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
            Firma.getInstance().notifyEmployeeListeners();
            dispose();
        
          }
            
        });
        
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
     }
    
    
 }