package vizual;

import java.util.*;
import javax.swing.*;

import obspattern.EmployeeListener;

import controllers.Firma;
import exceptions.AngajatInexistentException;

import model.Angajat;

import java.awt.event.*;
import java.awt.*;
import java.io.*;

public class MainFrame extends JFrame {
  
  private DefaultListModel<Angajat> model = new DefaultListModel<>();  
  public JList<Angajat> list = new JList<>(model); 
  private JScrollPane jsp = new JScrollPane(list);
  
  private JMenuBar mb = new JMenuBar();
  private JMenu m1 = new JMenu("Optiuni");
  private JMenuItem mi1 = new JMenuItem("Salveaza angajati");
  private JMenuItem mi2 = new JMenuItem("Importa angajati");
  
  private JPanel p1  = new JPanel(new FlowLayout(FlowLayout.LEFT));
  private JLabel e1 = new JLabel("NR ANGAJATI: 0");
  private JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
  private JButton b1 = new JButton("Adauga angajat");
  private JButton b2 = new JButton("Modifica date");
  
  private JButton b4 = new JButton("Sterge angajatul");
 
  
  private static MainFrame singleton = null;
  
  public static  MainFrame getInstance(){
    if(singleton == null) singleton  = new MainFrame();
    return singleton;
  }
  
  
  private MainFrame(){
    setJMenuBar(mb);
    mb.add(m1);
    m1.add(mi1);
    m1.add(mi2);
    add(jsp);  
    add(p1,BorderLayout.SOUTH);
    p1.add(e1);
    add(p2,BorderLayout.NORTH);
    p2.add(b1);p2.add(b2);p2.add(b4);
    
    mi1.addActionListener(new ActionListener () {
        public void actionPerformed(ActionEvent ev){
            try{
              JFileChooser chooser = new JFileChooser();
              int r = chooser.showSaveDialog(null);
                   if(r == JFileChooser.APPROVE_OPTION){
                
                    File file = chooser.getSelectedFile();
                    ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
                    out.writeObject(Firma.getInstance().getListaAngajati());
                
                    out.close();
                   }
             }catch(IOException e){};
        }
    
      });
      
    mi2.addActionListener(new ActionListener () {
        public void actionPerformed(ActionEvent ev){
            try{
              JFileChooser chooser = new JFileChooser();
              int r = chooser.showOpenDialog(null);
              FileInputStream sursa = null;
              if(r == JFileChooser.APPROVE_OPTION){
                File file = chooser.getSelectedFile();
                sursa = new FileInputStream (file);
              }
                  
                    Object o = null;
                    
                    ObjectInputStream in = new ObjectInputStream(sursa);
                    
                    
                    ArrayList<Angajat> lst = null;
                    try{
                        lst = ( ArrayList<Angajat>) in.readObject();
                    }catch(Exception ex) {};
                    
                    Firma.getInstance().setListaAngajati(lst);
                    Firma.getInstance().notifyEmployeeListeners();
                    
                    in.close();
                   
            }catch(IOException e){};
        }
    
      });
    
    
    new Thread(){
        public void run(){
            while(true){
                try{
                    Thread.sleep(1500);
                    e1.setText("NR ANGAJATI: "+Firma.getInstance().getListaAngajati().size()+"");
                }catch(Exception e){};
            }
            
        }
    
    }.start();
    
    
    
    b1.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
            AdaugaAngajatFrame f = new AdaugaAngajatFrame();
            f.setVisible(true);
        }
    
    });
    
    Firma.getInstance().addEmployee(new EmployeeListener(){
        public void listaAngajatiModificata(){
            afisareAngajati();
        }
    
    
    });
    
    
    b2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
            Angajat a = (Angajat) list.getSelectedValue();
            ModificaDateFrame f = new ModificaDateFrame(a);
            f.setVisible(true);
        }
    
    });
    
    b4.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
           Angajat a =(Angajat) list.getSelectedValue();
           try {
			Firma.getInstance().eliminaAngajat(a);
		} catch (AngajatInexistentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
           Firma.getInstance().notifyEmployeeListeners();
        }
    
    });
    
    setSize(700,500);
    setLocationRelativeTo(null);
    setVisible(true);
      
  }
  private void afisareAngajati(){
      model.clear();
      for(Angajat a:Firma.getInstance().getListaAngajati()){
          model.addElement(a);
      }
  }
  
  public static void main(String [] args){
        new MainFrame();
  }
}